package com.capstone.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoApplicationTests {

	@Test
	void contextLoads() {
		assertEquals(true, "Rohit".equals("Rohit"));
		//assertEquals(false, 1==1);
		assertEquals(true, 5==5);
		assertEquals(true, 6>1);
		assertEquals(false,true==false);		
	}

}
