package com.capstone.demo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MvnController {

	@RequestMapping("/hello")
	public String sayHello() {
		return "Hello Rohith";
	}
	
	@RequestMapping("/")
	public String demo() {
		return "Demo Application";
	}
}
